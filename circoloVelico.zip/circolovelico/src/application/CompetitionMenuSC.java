package application;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.URL;
import java.net.UnknownHostException;
import java.text.ParseException;
import java.util.ResourceBundle;

import classes.Server;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

public class CompetitionMenuSC implements Initializable{
	
    @FXML
    private TableColumn<Boat, Integer> boatLengthColumn;

    @FXML
    private TableColumn<Boat, String> boatNameColumn;

    @FXML
    private TableView<Boat> boatsTable;

    @FXML
    private Label communicationLabel;

    @FXML
    private TableColumn<Competition, String> compNameColumn;

    @FXML
    private TableView<Competition> competitionTable;

    @FXML
    private TableColumn<Competition, String> dateColumn;
    
    @FXML
    private ObservableList<Boat> boats= FXCollections.observableArrayList();
    
    @FXML
    private ObservableList<Competition> competitions= FXCollections.observableArrayList();
    
    private Server server=new Server ();
    private Member member;
    private Boat boatClicked;
    private Competition compClicked;
    Socket socket;
    BufferedReader read;
    PrintWriter output;
    
    public CompetitionMenuSC (Member memberx) throws UnknownHostException, IOException {
    	super();
    	this.member=memberx;
    	socket = new Socket("localhost", 9091);
		output = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()));
		read = new BufferedReader(new InputStreamReader(socket.getInputStream()));
    }

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		try {
			server.addPersonalGoodBoatToObsList(boats, member.getIdmember());
			server.addCompetitionToObsList(competitions);
			
			boatNameColumn.setCellValueFactory(new PropertyValueFactory<Boat, String>("name"));
			boatLengthColumn.setCellValueFactory(new PropertyValueFactory<Boat, Integer>("length"));
			compNameColumn.setCellValueFactory(new PropertyValueFactory<Competition, String>("name"));
			dateColumn.setCellValueFactory(new PropertyValueFactory<Competition, String>("date"));
			boatsTable.getItems().addAll(boats);
			competitionTable.getItems().addAll(competitions);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@FXML
    void back(ActionEvent event) throws IOException, ParseException {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("MemberMenu.fxml")); // load the file
    	MemberMenuSC newController= new MemberMenuSC(member); // create the controller
    	loader.setController(newController); // set the controller of the loader
    	Parent newRoot= loader.load();
    	Scene newScene = new Scene(newRoot); // create the scene with the root
    	Stage currentStage = (Stage)((Node) event.getSource()).getScene().getWindow();
    	currentStage.setScene(newScene);// set the stage with the scene
    	currentStage.show();
    }
    
    @FXML
    void boatRowClicked(MouseEvent event) {
    	boatClicked= boatsTable.getSelectionModel().getSelectedItem();
    }

    @FXML
    void competitionRowClicked(MouseEvent event) {
    	compClicked=competitionTable.getSelectionModel().getSelectedItem();
    }

    @FXML
    void registerCompetition(ActionEvent event) throws IOException {
    	if (boatClicked!= null && compClicked!= null) {
    		communicationLabel.setText("");
    		FXMLLoader loader = new FXMLLoader(getClass().getResource("PaymentNoPopMenu.fxml")); // load the file
    		PaymentRegistrationCompetitionSC newController= new PaymentRegistrationCompetitionSC(member,compClicked,boatClicked); // create the controller
        	loader.setController(newController); // set the controller of the loader
        	Parent newRoot= loader.load();
        	Scene newScene = new Scene(newRoot); // create the scene with the root
        	Stage currentStage = (Stage)((Node) event.getSource()).getScene().getWindow();
        	currentStage.setScene(newScene);// set the stage with the scene
        	currentStage.show();
    	}
    	else {
    		communicationLabel.setText("Please select boat and competition to register");
    	}
    }


}

