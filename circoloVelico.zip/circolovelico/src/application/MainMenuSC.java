package application;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.URL;
import java.text.ParseException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import classes.Server;
import javafx.fxml.Initializable;

public class MainMenuSC implements Initializable {

	private Scene scene;
	private Parent root;
	
	@FXML
	private PasswordField passwordInput;

    @FXML
    private TextField usernameInput;


    /*@FXML
    private Button loginButton;
    */
    @FXML
    private Label communicationMainMenu;
    
    
    Server server=new Server ();
    
    Socket socket;
    BufferedReader read;
    PrintWriter output;
   
	@FXML
	public void login(ActionEvent event)  throws IOException, ParseException
	{ 
		String username= usernameInput.getText();
		String password= passwordInput.getText();
		
		Member member=server.sendQuery(username, password);
		if (member != null) {
			//System.out.println(member.getAddress());
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ControlPanelMenu.fxml")); // load the file
			ControlPanelMenuSC newController= new ControlPanelMenuSC(member); // create the controller
        	loader.setController(newController); // set the controller of the loader
        	Parent newRoot= loader.load();
        	Scene newScene = new Scene(newRoot); // create the scene with the root
        	Stage currentStage = (Stage)((Node) event.getSource()).getScene().getWindow();
        	currentStage.setScene(newScene);// set the stage with the scene
        	currentStage.show();
		}
		else {
			communicationMainMenu.setText("username or password wrong");
		}
		
	}
	
	
	@FXML
	public void newMember(ActionEvent event)  throws IOException 
	{ 
		root = FXMLLoader.load(getClass().getResource("RegistrationMenu.fxml"));
		Stage currentStage = (Stage)((Node) event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		currentStage.setScene(scene);
		currentStage.show();
	}


	@Override
    public void initialize (final URL url, final ResourceBundle rb) {
		try {
			socket = new Socket("localhost", 9091);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			output = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			read = new BufferedReader(new InputStreamReader(socket.getInputStream()));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}
	
  

