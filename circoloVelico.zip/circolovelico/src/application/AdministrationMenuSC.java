package application;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class AdministrationMenuSC {
	
	private Member member;
	Socket socket;
    BufferedReader read;
    PrintWriter output;
	
	public AdministrationMenuSC (Member memberx) throws UnknownHostException, IOException {
		this.member=memberx;
		socket = new Socket("localhost", 9091);
		output = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()));
		read = new BufferedReader(new InputStreamReader(socket.getInputStream()));
	}

    @FXML
    void openAllBoats(ActionEvent event) throws IOException {
    	FXMLLoader loader = new FXMLLoader(getClass().getResource("AdminBoatMenu.fxml")); // load the file
    	AdminBoatMenuSC newController= new AdminBoatMenuSC(member); // create the controller
    	loader.setController(newController); // set the controller of the loader
    	Parent newRoot= loader.load();
    	Scene newScene = new Scene(newRoot); // create the scene with the root
    	Stage currentStage = (Stage)((Node) event.getSource()).getScene().getWindow();
    	currentStage.setScene(newScene);// set the stage with the scene
    	currentStage.show();
    }
    
    @FXML
    void openAllMembers(ActionEvent event) throws IOException {
    	FXMLLoader loader = new FXMLLoader(getClass().getResource("AdminMemberMenu.fxml")); // load the file
    	AdminMemberMenuSC newController= new AdminMemberMenuSC(member); // create the controller
    	loader.setController(newController); // set the controller of the loader
    	Parent newRoot= loader.load();
    	Scene newScene = new Scene(newRoot); // create the scene with the root
    	Stage currentStage = (Stage)((Node) event.getSource()).getScene().getWindow();
    	currentStage.setScene(newScene);// set the stage with the scene
    	currentStage.show();
    }
    
    @FXML
    void openPayments(ActionEvent event) throws IOException {
    	FXMLLoader loader = new FXMLLoader(getClass().getResource("AdminAllPaymentsMenu.fxml")); // load the file
    	AdminAllPaymentsMenuSC newController= new AdminAllPaymentsMenuSC(member); // create the controller
    	loader.setController(newController); // set the controller of the loader
    	Parent newRoot= loader.load();
    	Scene newScene = new Scene(newRoot); // create the scene with the root
    	Stage currentStage = (Stage)((Node) event.getSource()).getScene().getWindow();
    	currentStage.setScene(newScene);// set the stage with the scene
    	currentStage.show();
    }
    
    @FXML
    void back(ActionEvent event) throws IOException {
    	FXMLLoader loader = new FXMLLoader(getClass().getResource("ControlPanelMenu.fxml")); // load the file
		ControlPanelMenuSC newController= new ControlPanelMenuSC(member); // create the controller
    	loader.setController(newController); // set the controller of the loader
    	Parent newRoot= loader.load();
    	Scene newScene = new Scene(newRoot); // create the scene with the root
    	Stage currentStage = (Stage)((Node) event.getSource()).getScene().getWindow();
    	currentStage.setScene(newScene);// set the stage with the scene
    	currentStage.show();
    }

}
