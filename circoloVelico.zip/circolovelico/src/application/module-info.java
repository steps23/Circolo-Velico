module Sp {
	requires javafx.controls;
	requires javafx.fxml;
	requires javafx.base;
	requires java.sql;
	requires javafx.graphics;
	//requires junit;
	
	
	opens application to javafx.graphics, javafx.fxml,javafx.base;
	
}
