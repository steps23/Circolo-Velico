package application;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.URL;
import java.net.UnknownHostException;
import java.text.ParseException;
import java.util.ResourceBundle;

import classes.Server;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class AllRacesRegistationMenuSC implements Initializable {

    @FXML
    private TableColumn<Registration, String> boatNameColumn;
    
    @FXML
    private TableColumn<Registration, String> competitionDateColumn;

    @FXML
    private TableColumn<Registration, String> competitionNameColumn;

    @FXML
    private TableColumn<Registration, Integer> idBoatRegColumn;

    @FXML
    private TableColumn<Registration, Integer> idCompetitionColumn;

    @FXML
    private TableColumn<Registration, Integer> idMemberRegColumn;

    @FXML
    private TableColumn<Registration, Integer> idregistrationColumn;

    @FXML
    private TableColumn<Registration, String> memberNameColumn;

    @FXML
    private TableView<Registration> registrationTable;
    
    @FXML
    private ObservableList<Registration> registrations= FXCollections.observableArrayList();
    
    private Server server=new Server ();
    private Member member;
    Socket socket;
    BufferedReader read;
    PrintWriter output;

    public AllRacesRegistationMenuSC (Member memberx) throws UnknownHostException, IOException {
		super();
		this.member= memberx;
		socket = new Socket("localhost", 9091);
		output = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()));
		read = new BufferedReader(new InputStreamReader(socket.getInputStream()));
	}
    
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		server.addRegistrationToObsList(registrations);
		idregistrationColumn.setCellValueFactory(new PropertyValueFactory<Registration, Integer>("idregistration"));
		idMemberRegColumn.setCellValueFactory(new PropertyValueFactory<Registration, Integer>("idMemberReg"));
		memberNameColumn.setCellValueFactory(new PropertyValueFactory<Registration, String>("memberName"));
		idBoatRegColumn.setCellValueFactory(new PropertyValueFactory<Registration, Integer>("idBoatReg"));
		boatNameColumn.setCellValueFactory(new PropertyValueFactory<Registration, String>("boatName"));
		idCompetitionColumn.setCellValueFactory(new PropertyValueFactory<Registration, Integer>("idCompetitionReg"));
		competitionNameColumn.setCellValueFactory(new PropertyValueFactory<Registration, String>("competitionName"));
		competitionDateColumn.setCellValueFactory(new PropertyValueFactory<Registration, String>("competitionDate"));
		registrationTable.getItems().addAll(registrations);
	}
    
	@FXML
    void back(ActionEvent event) throws IOException, ParseException {
		int type= member.getType();
		server.updateMember(member);
		if(type != member.getType()) {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ControlPanelMenu.fxml")); // load the file
			ControlPanelMenuSC newController= new ControlPanelMenuSC(member); // create the controller
        	loader.setController(newController); // set the controller of the loader
        	Parent newRoot= loader.load();
        	Scene newScene = new Scene(newRoot); // create the scene with the root
        	Stage currentStage = (Stage)((Node) event.getSource()).getScene().getWindow();
        	currentStage.setScene(newScene);// set the stage with the scene
        	currentStage.show();
		}
		else {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("StaffMenu.fxml")); // load the file
			StaffMenuSC newController= new StaffMenuSC(member); // create the controller
	    	loader.setController(newController); // set the controller of the loader
	    	Parent newRoot= loader.load();
	    	Scene newScene = new Scene(newRoot); // create the scene with the root
	    	Stage currentStage = (Stage)((Node) event.getSource()).getScene().getWindow();
	    	currentStage.setScene(newScene);// set the stage with the scene
	    	currentStage.show();
		}
		
    }

}
