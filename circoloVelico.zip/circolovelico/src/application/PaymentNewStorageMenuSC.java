package application;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ResourceBundle;

import classes.Server;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class PaymentNewStorageMenuSC implements Initializable{
	
	

    @FXML
    private TextField codePayment;

    @FXML
    private Label communicationErrorPayment,communicationPayment;

    @FXML
    private RadioButton creditCardRB;

    @FXML
    private RadioButton ibanRB;
    
    private String reason= new String(), typePayment=new String (),codePaymentx=new String();
    private String communication=new String();
    private Server server=new Server ();
    private Member member;
    private String name;
    private int length,amount;
    
    Socket socket;
    BufferedReader read;
    PrintWriter output;
    
    public PaymentNewStorageMenuSC (Member memberx,String namex,int lengthx) throws UnknownHostException, IOException {
    	super();
    	this.member=memberx;
    	this.name=namex;
    	this.length=lengthx;
    	this.calculateAmout();
    	this.setReason();
    	
    	socket = new Socket("localhost", 9091);
		output = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()));
		read = new BufferedReader(new InputStreamReader(socket.getInputStream()));
    }

    @Override
	public void initialize(URL arg0, ResourceBundle arg1) {
    	this.setCommunication();
    	communicationPayment.setText(communication);
	}
    
    @FXML
    void back(ActionEvent event) throws IOException {
    	FXMLLoader loader = new FXMLLoader(getClass().getResource("StorageBoatMenu.fxml")); // load the file
    	StorageBoatMenuSC newController= new StorageBoatMenuSC(member); // create the controller
    	loader.setController(newController); // set the controller of the loader
    	Parent newRoot= loader.load();
    	Scene newScene = new Scene(newRoot); // create the scene with the root
    	Stage currentStage = (Stage)((Node) event.getSource()).getScene().getWindow();
    	currentStage.setScene(newScene);// set the stage with the scene
    	currentStage.show();
    }
    
    @FXML
    void getTypePayment(ActionEvent event) throws IOException{
    	if(creditCardRB.isSelected()) {
			typePayment= creditCardRB.getText();
			
		}
		else if(ibanRB.isSelected()){
			typePayment=ibanRB.getText();
		}
    }

    @FXML
    void yesButtonPress(ActionEvent event) throws IOException{
    	boolean a= false, b=false;
		codePaymentx=codePayment.getText();
		if (typePayment.equals("credit card") || typePayment.equals("iban")) {
			a=true;
		}
		if(codePaymentx.length()==10) {
			b=true;
		}
		if(a && b ) {
			communicationErrorPayment.setText("");
			server.addNewBoat(name, length, member.getIdmember());
			server.addPayment(member.getIdmember(), amount, reason, typePayment, codePaymentx);
			
			FXMLLoader loader = new FXMLLoader(getClass().getResource("BoatMenu.fxml")); // load the file
	    	BoatMenuSC newController= new BoatMenuSC(member); // create the controller
	    	loader.setController(newController); // set the controller of the loader
	    	Parent newRoot= loader.load();
	    	Scene newScene = new Scene(newRoot); // create the scene with the root
	    	Stage currentStage = (Stage)((Node) event.getSource()).getScene().getWindow();
	    	currentStage.setScene(newScene);// set the stage with the scene
	    	currentStage.show();
		}
		else {
			communicationErrorPayment.setText("Complete correctly all fields!");
		}
    	
    }
    
    public void calculateAmout() {
    	if (this.length <5) {
    		this.amount=50;
    	}
    	else if(this.length >=5 && this.length<10) {
    		this.amount=100;
    	}
    	else if(this.length >=10 && this.length<15) {
    		this.amount=150;
    	}
    	else if(this.length >=15) {
    		this.amount=200;
    	}
    }
    
    public void setReason() {
    	this.reason= this.name + " boat storage";
    }

	public void setCommunication() {
		this.communication = "You have to pay "+ Integer.toString(this.amount)+" for "+ this.reason;
	}
}
