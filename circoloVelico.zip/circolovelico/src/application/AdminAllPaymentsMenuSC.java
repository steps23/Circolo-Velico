package application;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ResourceBundle;

import classes.Server;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class AdminAllPaymentsMenuSC implements Initializable {
	
    @FXML
    private TableColumn<Payment, Integer> amountColumn;

    @FXML
    private TableColumn<Payment, String> codePaymentColumn;

    @FXML
    private TableColumn<Payment, Integer> idMemberPayColumn;

    @FXML
    private TableColumn<Payment, Integer> idpaymentColumn;

    @FXML
    private TableColumn<Payment, String> nameMemberPaycolumn;

    @FXML
    private TableColumn<Payment, String> reasonColumn;

    @FXML
    private TableColumn<Payment, String> typePaymentColumn;
    
    @FXML
    private TableView<Payment> paymentsTable;
    
    @FXML
    private ObservableList<Payment> payments= FXCollections.observableArrayList();

    Socket socket;
    BufferedReader read;
    PrintWriter output;
    
    private Server server= new Server ();
    private Member member;
    
    
    
    public AdminAllPaymentsMenuSC (Member memberx) throws UnknownHostException, IOException {
    	this.member=memberx;
    	socket = new Socket("localhost", 9091);
		output = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()));
		read = new BufferedReader(new InputStreamReader(socket.getInputStream()));
    }

    @FXML
    void back(ActionEvent event) throws IOException {
    	FXMLLoader loader = new FXMLLoader(getClass().getResource("AdministrationMenu.fxml")); // load the file
		AdministrationMenuSC newController= new AdministrationMenuSC(member); // create the controller
    	loader.setController(newController); // set the controller of the loader
    	Parent newRoot= loader.load();
    	Scene newScene = new Scene(newRoot); // create the scene with the root
    	Stage currentStage = (Stage)((Node) event.getSource()).getScene().getWindow();
    	currentStage.setScene(newScene);// set the stage with the scene
    	currentStage.show();
    }

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		server.addPaymentsToObsList(payments);
		
		idpaymentColumn.setCellValueFactory(new PropertyValueFactory<Payment, Integer>("idpayment"));
		idMemberPayColumn.setCellValueFactory(new PropertyValueFactory<Payment, Integer>("idMemberPay"));
		nameMemberPaycolumn.setCellValueFactory(new PropertyValueFactory<Payment, String>("nameMember"));
		amountColumn.setCellValueFactory(new PropertyValueFactory<Payment, Integer>("amount"));
		reasonColumn.setCellValueFactory(new PropertyValueFactory<Payment, String>("reason"));
		typePaymentColumn.setCellValueFactory(new PropertyValueFactory<Payment, String>("typePayment"));
		codePaymentColumn.setCellValueFactory(new PropertyValueFactory<Payment, String>("codePayment"));
		paymentsTable.getItems().addAll(payments);
	}

}
