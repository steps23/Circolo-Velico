package application;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.URL;
import java.net.UnknownHostException;
import java.text.ParseException;
import java.util.ResourceBundle;

import classes.Server;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class ControlPanelMenuSC implements Initializable{
	
	private Scene scene;
	private Parent root;
	
    @FXML
    private Label communicationLabel;
    
    private Member member;
    private Server server=new Server ();
    private int type;
    
    Socket socket;
    BufferedReader read;
    PrintWriter output;
    
    public ControlPanelMenuSC (Member memberx) throws UnknownHostException, IOException {
    	super();
    	
    	socket = new Socket("localhost", 9091);
		output = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()));
		read = new BufferedReader(new InputStreamReader(socket.getInputStream()));
    	
    	this.member= memberx;
    	this.type=this.member.getType();
    	
    	
    }
    
    @Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
	}
    
    @FXML
    void back(ActionEvent event) throws IOException {
    	root = FXMLLoader.load(getClass().getResource("MainMenu.fxml"));
		Stage currentStage = (Stage)((Node) event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		currentStage.setScene(scene);
		currentStage.show();
    }
	
    @FXML
    void goAdminArea(ActionEvent event) throws IOException {
    	if(type==1) {
    		FXMLLoader loader = new FXMLLoader(getClass().getResource("AdministrationMenu.fxml")); // load the file
    		AdministrationMenuSC newController= new AdministrationMenuSC(member); // create the controller
        	loader.setController(newController); // set the controller of the loader
        	Parent newRoot= loader.load();
        	Scene newScene = new Scene(newRoot); // create the scene with the root
        	Stage currentStage = (Stage)((Node) event.getSource()).getScene().getWindow();
        	currentStage.setScene(newScene);// set the stage with the scene
        	currentStage.show();
    	}
    	else {
    		communicationLabel.setText("Sorry you can't access this panel because you haven't admin privilage");
    	}
    }

    @FXML
    void goMemberArea(ActionEvent event) throws IOException, ParseException {
    	if(type==1 || type==2 || type==3) {
    		FXMLLoader loader = new FXMLLoader(getClass().getResource("MemberMenu.fxml")); // load the file
        	MemberMenuSC newController= new MemberMenuSC(member); // create the controller
        	loader.setController(newController); // set the controller of the loader
        	Parent newRoot= loader.load();
        	Scene newScene = new Scene(newRoot); // create the scene with the root
        	Stage currentStage = (Stage)((Node) event.getSource()).getScene().getWindow();
        	currentStage.setScene(newScene);// set the stage with the scene
        	currentStage.show();
    	}
    	else {
    		communicationLabel.setText("Sorry you can't access this panel because you haven't staff privilage");
    	}
    	
    }

    @FXML
    void goStaffArea(ActionEvent event) throws IOException {
    	server.updateMember(member);
    	this.type=this.member.getType();
    	if(type==1 || type==2) {
    		FXMLLoader loader = new FXMLLoader(getClass().getResource("StaffMenu.fxml")); // load the file
    		StaffMenuSC newController= new StaffMenuSC(member); // create the controller
        	loader.setController(newController); // set the controller of the loader
        	Parent newRoot= loader.load();
        	Scene newScene = new Scene(newRoot); // create the scene with the root
        	Stage currentStage = (Stage)((Node) event.getSource()).getScene().getWindow();
        	currentStage.setScene(newScene);// set the stage with the scene
        	currentStage.show();
    	}
    	else {
    		communicationLabel.setText("Sorry you can't access this panel because you haven't this privilage");
    	}
    }

	

}
