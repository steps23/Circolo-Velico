package application;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.text.ParseException;

import classes.Server;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class StaffMenuSC {
	
	private Member member;
	private Server server=new Server ();
	Socket socket;
    BufferedReader read;
    PrintWriter output;
	
	public StaffMenuSC (Member memberx) throws UnknownHostException, IOException {
		this.member=memberx;
		socket = new Socket("localhost", 9091);
		output = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()));
		read = new BufferedReader(new InputStreamReader(socket.getInputStream()));
	}

    @FXML
    void back(ActionEvent event) throws ParseException, IOException {
    	FXMLLoader loader = new FXMLLoader(getClass().getResource("ControlPanelMenu.fxml")); // load the file
		ControlPanelMenuSC newController= new ControlPanelMenuSC(member); // create the controller
    	loader.setController(newController); // set the controller of the loader
    	Parent newRoot= loader.load();
    	Scene newScene = new Scene(newRoot); // create the scene with the root
    	Stage currentStage = (Stage)((Node) event.getSource()).getScene().getWindow();
    	currentStage.setScene(newScene);// set the stage with the scene
    	currentStage.show();
    }

    @FXML
    void organizeCompetition(ActionEvent event) throws IOException {
    	int type= member.getType();
		server.updateMember(member);
		if(type != member.getType()) {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ControlPanelMenu.fxml")); // load the file
			ControlPanelMenuSC newController= new ControlPanelMenuSC(member); // create the controller
        	loader.setController(newController); // set the controller of the loader
        	Parent newRoot= loader.load();
        	Scene newScene = new Scene(newRoot); // create the scene with the root
        	Stage currentStage = (Stage)((Node) event.getSource()).getScene().getWindow();
        	currentStage.setScene(newScene);// set the stage with the scene
        	currentStage.show();
		}
		else {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("NewCompetitionMenu.fxml")); // load the file
	    	NewCompetitionMenuSC newController= new NewCompetitionMenuSC(member); // create the controller
	    	loader.setController(newController); // set the controller of the loader
	    	Parent newRoot= loader.load();
	    	Scene newScene = new Scene(newRoot); // create the scene with the root
	    	Stage currentStage = (Stage)((Node) event.getSource()).getScene().getWindow();
	    	currentStage.setScene(newScene);// set the stage with the scene
	    	currentStage.show();
		}
    	
    }
    
    @FXML
    void registrationPressed(ActionEvent event) throws IOException {
    	int type= member.getType();
		server.updateMember(member);
		if(type != member.getType()) {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ControlPanelMenu.fxml")); // load the file
			ControlPanelMenuSC newController= new ControlPanelMenuSC(member); // create the controller
        	loader.setController(newController); // set the controller of the loader
        	Parent newRoot= loader.load();
        	Scene newScene = new Scene(newRoot); // create the scene with the root
        	Stage currentStage = (Stage)((Node) event.getSource()).getScene().getWindow();
        	currentStage.setScene(newScene);// set the stage with the scene
        	currentStage.show();
		}
		else {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("RaceRegistrationMenu.fxml")); // load the file
	    	AllRacesRegistationMenuSC newController= new AllRacesRegistationMenuSC(member); // create the controller
	    	loader.setController(newController); // set the controller of the loader
	    	Parent newRoot= loader.load();
	    	Scene newScene = new Scene(newRoot); // create the scene with the root
	    	Stage currentStage = (Stage)((Node) event.getSource()).getScene().getWindow();
	    	currentStage.setScene(newScene);// set the stage with the scene
	    	currentStage.show();
		}
    	
    }
}
