package application;
	
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;

/**
 * Main is the main class 
 * 
 * 
 * @author 		Stefano Ruggiero stefano.ruggiero@studenti.unipr.it mat.305880
 * @author		Chiara Piroli chiara.piroli1@studenti.unipr.it mat.308102
 * 
 * @version 	1.0
 * @since  		1.0
 *
 */


public class Main extends Application {
	
    /*Socket socket;
    BufferedReader read;
    PrintWriter output;*/
    
	@Override
	public void start(Stage primaryStage) {
		try {
			
			/*socket = new Socket("localhost", 9091);
			output = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()));
			read = new BufferedReader(new InputStreamReader(socket.getInputStream()));*/
		
			FXMLLoader fxml =new FXMLLoader(getClass().getResource("MainMenu.fxml"));//load the fxml file
			/*SceneController s = new SceneController();
			fxml.setController(s);*/
			Parent root = fxml.load();//create the root
			Scene scene = new Scene(root);// create the scene
			primaryStage.setScene(scene);// set the scene of the stage
			primaryStage.show();//show the stage
			
		   
		} catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	/**
	 * Start the application
	 * 
	 */
	
	public static void main(String[] args) {
		launch(args);
	}
}
