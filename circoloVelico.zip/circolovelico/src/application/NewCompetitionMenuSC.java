package application;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.URL;
import java.net.UnknownHostException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ResourceBundle;

import classes.Server;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;


public class NewCompetitionMenuSC implements Initializable{
	
	@FXML
    private DatePicker datePicker;
	
    @FXML
    private TextField nameTextField;
    
    @FXML
    private Label communicationLabel;
	
	private Member member;
	
	private String name;
	
	private LocalDate date;
	
    private Server server=new Server ();
    
    Socket socket;
    BufferedReader read;
    PrintWriter output;
	
	
	public NewCompetitionMenuSC (Member memberx) throws UnknownHostException, IOException {
		this.member = memberx;
		socket = new Socket("localhost", 9091);
		output = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()));
		read = new BufferedReader(new InputStreamReader(socket.getInputStream()));
	}
	

    @FXML
    void back(ActionEvent event) throws IOException {
    	int type= member.getType();
		server.updateMember(member);
		if(type != member.getType()) {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ControlPanelMenu.fxml")); // load the file
			ControlPanelMenuSC newController= new ControlPanelMenuSC(member); // create the controller
        	loader.setController(newController); // set the controller of the loader
        	Parent newRoot= loader.load();
        	Scene newScene = new Scene(newRoot); // create the scene with the root
        	Stage currentStage = (Stage)((Node) event.getSource()).getScene().getWindow();
        	currentStage.setScene(newScene);// set the stage with the scene
        	currentStage.show();
		}
		else {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("StaffMenu.fxml")); // load the file
			StaffMenuSC newController= new StaffMenuSC(member); // create the controller
	    	loader.setController(newController); // set the controller of the loader
	    	Parent newRoot= loader.load();
	    	Scene newScene = new Scene(newRoot); // create the scene with the root
	    	Stage currentStage = (Stage)((Node) event.getSource()).getScene().getWindow();
	    	currentStage.setScene(newScene);// set the stage with the scene
	    	currentStage.show();
		}
    	
    }
	
   
    @FXML
    void addCompetition(ActionEvent event) throws ParseException, IOException {
    	int type= member.getType();
		server.updateMember(member);
		if(type != member.getType()) {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ControlPanelMenu.fxml")); // load the file
			ControlPanelMenuSC newController= new ControlPanelMenuSC(member); // create the controller
        	loader.setController(newController); // set the controller of the loader
        	Parent newRoot= loader.load();
        	Scene newScene = new Scene(newRoot); // create the scene with the root
        	Stage currentStage = (Stage)((Node) event.getSource()).getScene().getWindow();
        	currentStage.setScene(newScene);// set the stage with the scene
        	currentStage.show();
		}
		else {
			name= nameTextField.getText();
	    	System.out.println(name);
	    	
	    	if(name != null && name.length()>=3 && date!=null && !this.expiredDate()) {
	    		server.addCompetition(name, date.toString(), member.getIdmember());
	    		this.back(event);
	    	}
	    	else {
	    		communicationLabel.setText("Please fill all the fields correctly");
	    	}
		}
    	
    }

    @FXML
    void getDate(ActionEvent event) throws ParseException {
    	date= datePicker.getValue();
    	System.out.println(date.toString());
    	
    }
    
    public boolean expiredDate() throws ParseException {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		LocalDate dateNow = LocalDate.now();
		int compareValue = dateNow.compareTo(date);
		if(compareValue>0) {
			//System.out.println("SCADUTO");
			return true;	
		}
		else {
			//System.out.println("NON SCADUTO");
			return false;
		}
	}


	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}
    
}
