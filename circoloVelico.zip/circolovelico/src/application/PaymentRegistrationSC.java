package application;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.URL;
import java.net.UnknownHostException;
import java.text.ParseException;
import java.util.ResourceBundle;

import classes.Server;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class PaymentRegistrationSC implements Initializable{

	
	
	@FXML
    private TextField codePayment;

    @FXML
    private Label communicationErrorPayment,communicationPayment;

    @FXML
    private RadioButton creditCardRB;

    @FXML
    private RadioButton ibanRB;
    
    private String reason= new String("registration"), typePayment=new String (),codePaymentx=new String();
    private int amount=150;
    private String communication=new String();
    private Server server=new Server ();
    private Member member;
    
    Socket socket;
    BufferedReader read;
    PrintWriter output;
    
    public PaymentRegistrationSC (Member memberx) throws UnknownHostException, IOException {
    	super();
    	this.member=memberx;
    	socket = new Socket("localhost", 9091);
		output = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()));
		read = new BufferedReader(new InputStreamReader(socket.getInputStream()));
    }
    
    @Override
	public void initialize(URL arg0, ResourceBundle arg1) {
    	this.setCommunication();
    	communicationPayment.setText(communication);
	}
    
    @FXML
    void back(ActionEvent event) throws IOException, ParseException {
    	FXMLLoader loader = new FXMLLoader(getClass().getResource("MemberMenu.fxml")); // load the file
    	MemberMenuSC newController= new MemberMenuSC(member); // create the controller
    	loader.setController(newController); // set the controller of the loader
    	Parent newRoot= loader.load();
    	Scene newScene = new Scene(newRoot); // create the scene with the root
    	Stage currentStage = (Stage)((Node) event.getSource()).getScene().getWindow();
    	currentStage.setScene(newScene);// set the stage with the scene
    	currentStage.show();
    }

    @FXML
    void getTypePayment(ActionEvent event) {
    	if(creditCardRB.isSelected()) {
			typePayment= creditCardRB.getText();
		}
		else if(ibanRB.isSelected()){
			typePayment=ibanRB.getText();
		}
    }

    @FXML
    void yesButtonPress(ActionEvent event) throws IOException, ParseException{
    	boolean a= false, b=false;
		codePaymentx=codePayment.getText();
		if (typePayment.equals("credit card") || typePayment.equals("iban")) {
			a=true;
		}
		if(codePaymentx.length()==10) {
			b=true;
		}
		if(a && b ) {
			communicationErrorPayment.setText("");
			server.updateDateMember(member);
			server.addPayment(member.getIdmember(), amount, reason, typePayment, codePaymentx);
			this.back(event);
		}
		else {
			communicationErrorPayment.setText("Complete correctly all fields!");
		}
    	
    }
    
    public void setCommunication() {
		this.communication = "You have to pay "+ Integer.toString(this.amount)+" for "+ this.reason;
	}
}
