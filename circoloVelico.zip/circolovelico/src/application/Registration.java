package application;

/**
 * The registration object
 * 
 * 
 * @author 		Stefano Ruggiero stefano.ruggiero@studenti.unipr.it mat.305880
 * @author		Chiara Piroli chiara.piroli1@studenti.unipr.it mat.308102
 * 
 * @version 	1.0
 * @since  		1.0
 *
 */

public class Registration {
	
	private final int idregistration;
	private final int idMemberReg;
	private final int idBoatReg;
	private final int idCompetitionReg;
	private String memberName;
	private String boatName;
	private String competitionName;
	private String competitionDate;
	
	/**
	 * Creates the registration object only with the IDs
	 * 
	 * @param idregistration
	 * @param idMemberReg
	 * @param idBoatReg
	 * @param idCompetitionReg
	 */
	
	public Registration(int idregistration, int idMemberReg, int idBoatReg, int idCompetitionReg) {
		super();
		this.idregistration = idregistration;
		this.idMemberReg = idMemberReg;
		this.idBoatReg = idBoatReg;
		this.idCompetitionReg = idCompetitionReg;
	}

	/**
	 * Creates the registration object with all the parameters
	 * 
	 * @param idregistration
	 * @param idMemberReg
	 * @param idBoatReg
	 * @param idCompetitionReg
	 * @param memberName
	 * @param boatName
	 * @param competitionName
	 * @param competitionDate
	 */
	
	public Registration(int idregistration, int idMemberReg, int idBoatReg, int idCompetitionReg, String memberName,
			String boatName, String competitionName, String competitionDate) {
		super();
		this.idregistration = idregistration;
		this.idMemberReg = idMemberReg;
		this.idBoatReg = idBoatReg;
		this.idCompetitionReg = idCompetitionReg;
		this.memberName = memberName;
		this.boatName = boatName;
		this.competitionName = competitionName;
		this.competitionDate = competitionDate;
	}

	/**
	 * return the id of the registration
	 * 
	 * @return
	 */
	
	public int getIdregistration() {
		return idregistration;
	}

	/**
	 * get the id of the member that had created the competition 
	 * 
	 * @return
	 */
	
	public int getIdMemberReg() {
		return idMemberReg;
	}

	/**
	 * get the id of the boat registered
	 * 
	 * @return
	 */
	
	public int getIdBoatReg() {
		return idBoatReg;
	}


	/**
	 * get the id of the competition
	 * 
	 * @return
	 */
	
	public int getIdCompetitionReg() {
		return idCompetitionReg;
	}
	
	
	/**
	 * get the name of the member registered
	 * 
	 * @return
	 */
	
	public String getMemberName() {
		return memberName;
	}

	/**
	 * set the name of the member registered
	 * 
	 * @param memberName
	 */
	
	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	/**
	 * get the name of the boat registered
	 * 
	 * @return
	 */

	public String getBoatName() {
		return boatName;
	}

	/**
	 * set the name of the boat registered
	 * 
	 * @param boatName
	 */

	public void setBoatName(String boatName) {
		this.boatName = boatName;
	}

	/**
	 * get the name of the competition
	 * 
	 * @return
	 */

	public String getCompetitionName() {
		return competitionName;
	}

	/**
	 * set the name of the competition
	 * 
	 * @param competitionName
	 */

	public void setCompetitionName(String competitionName) {
		this.competitionName = competitionName;
	}

	/**
	 * get the date of the competition
	 * 
	 * @return
	 */
	
	public String getCompetitionDate() {
		return competitionDate;
	}

	/**
	 * set the date of the competition
	 * 
	 * @param competitionDate
	 */
	
	public void setCompetitionDate(String competitionDate) {
		this.competitionDate = competitionDate;
	}


}
