package application;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class StorageBoatMenuSC implements Initializable{
	


	@FXML
    private TextField lengthInput;

    @FXML
    private TextField nameInput;
    
    @FXML
    private Label communicationError;
    
    private Member member;
    private Integer length;
    private String name;
    Socket socket;
    BufferedReader read;
    PrintWriter output;
    
    public StorageBoatMenuSC (Member memberx) throws UnknownHostException, IOException {
    	super();
		this.member= memberx;
		socket = new Socket("localhost", 9091);
		output = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()));
		read = new BufferedReader(new InputStreamReader(socket.getInputStream()));
    }

    @FXML
    void registrationButtonPressed(ActionEvent event) throws IOException{
    	this.name = this.nameInput.getText();
    	if (isNumeric(lengthInput.getText())) {
    		length= Integer.parseInt(lengthInput.getText());
    	}
    	else {
    		this.communicationError.setText("Incorrect input,insert correct number or integer");
    	}
    	if (this.name != null && this.name.length()>=2 && this.length != null) {
    		FXMLLoader loader = new FXMLLoader(getClass().getResource("PaymentNoPopMenu.fxml")); // load the file
        	PaymentNewStorageMenuSC newController= new PaymentNewStorageMenuSC(this.member,this.name,this.length); // create the controller
        	loader.setController(newController); // set the controller of the loader
        	Parent newRoot= loader.load();
        	Scene newScene = new Scene(newRoot); // create the scene with the root
        	Stage currentStage = (Stage)((Node) event.getSource()).getScene().getWindow();
        	currentStage.setScene(newScene);// set the stage with the scene
        	currentStage.show();
    	}
    	else {
    		this.communicationError.setText("Incorrect input");
    	}
    }
    
    @FXML
    void back(ActionEvent event) throws IOException {
    	FXMLLoader loader = new FXMLLoader(getClass().getResource("BoatMenu.fxml")); // load the file
    	BoatMenuSC newController= new BoatMenuSC(member); // create the controller
    	loader.setController(newController); // set the controller of the loader
    	Parent newRoot= loader.load();
    	Scene newScene = new Scene(newRoot); // create the scene with the root
    	Stage currentStage = (Stage)((Node) event.getSource()).getScene().getWindow();
    	currentStage.setScene(newScene);// set the stage with the scene
    	currentStage.show();
    }

    public boolean isNumeric(String string) {
	    int intValue;
			
	    System.out.println(String.format("Parsing string: \"%s\"", string));
			
	    if(string == null || string.equals("")) {
	        System.out.println("String cannot be parsed, it is null or empty.");
	        return false;
	    }
	    
	    try {
	        intValue = Integer.parseInt(string);
	        return true;
	    } catch (NumberFormatException e) {
	        System.out.println("Input String cannot be parsed to Integer.");
	    }
	    return false;
	}
    
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
	}
	
}
