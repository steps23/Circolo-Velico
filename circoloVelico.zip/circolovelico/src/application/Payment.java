package application;

import classes.Server;

/**
 * The payment object
 * 
 * 
 * @author 		Stefano Ruggiero stefano.ruggiero@studenti.unipr.it mat.305880
 * @author		Chiara Piroli chiara.piroli1@studenti.unipr.it mat.308102
 * 
 * @version 	1.0
 * @since  		1.0
 *
 */

public class Payment {

	
	private final int idpayment;
	private int amount;
	private final int idMemberPay;
	private String reason;
	private String typePayment;
	private String codePayment;
	
	/**
	 * Creates the payment object
	 * 
	 * @param idpayment
	 * @param idMemberPay
	 * @param amount
	 * @param reason
	 * @param typePayment
	 * @param codePayment
	 */
	
	public Payment(int idpayment, int idMemberPay, int amount, String reason, String typePayment, String codePayment) {
		super();
		this.idpayment = idpayment;
		this.amount = amount;
		this.reason = reason;
		this.typePayment = typePayment;
		this.codePayment = codePayment;
		this.idMemberPay = idMemberPay;
	}
	
	/**
	 * return the amount of the payment
	 * 
	 * @return
	 */
	
	public int getAmount() {
		return amount;
	}
	
	/**
	 * set the amount of the payment
	 * 
	 * @param amount
	 */
	
	public void setAmount(int amount) {
		this.amount = amount;
	}
	
	/**
	 * return the reason of the payment
	 * 
	 * @return
	 */
	
	public String getReason() {
		return reason;
	}
	
	/**
	 * set the reason of the payment
	 * 
	 * @param reason
	 */
	
	public void setReason(String reason) {
		this.reason = reason;
	}
	
	/**
	 * return the the type of the payment
	 * 
	 * @return
	 */
	
	public String getTypePayment() {
		return typePayment;
	}
	
	/**
	 * set the type of the payment
	 * 
	 * @param typePayment
	 */
	
	public void setTypePayment(String typePayment) {
		this.typePayment = typePayment;
	}
	
	/**
	 * return the code of the payment
	 * 
	 * @return
	 */
	
	public String getCodePayment() {
		return codePayment;
	}
	
	/**
	 * set the payment of the payment
	 * 
	 * @param codePayment
	 */
	
	public void setCodePayment(String codePayment) {
		this.codePayment = codePayment;
	}
	
	/**
	 * return the id of the payment
	 * 
	 * @return
	 */
	
	public int getIdpayment() {
		return idpayment;
	}
	
	/**
	 * return the id of the member
	 * 
	 * @return
	 */
	
	public int getIdMemberPay() {
		return idMemberPay;
	}
	
	/**
	 * return the name of the member
	 * 
	 * @return
	 */
	
	public String getNameMember() {
		Server server= new Server();
		String name=server.getNameMemberFromId(idMemberPay);
		return name;
	}
	
	
	
}
