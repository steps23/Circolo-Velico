package application;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.scene.Node;
import classes.Server;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class PaymentNewRegistrationPopMenuSC implements Initializable {

	
	@FXML
	private TextField codePayment;
	
	@FXML
	private Label communicationPayment, communicationErrorPayment;
	
	@FXML
	private RadioButton creditCardRB, ibanRB;
	
	private String name, surname, address, fiscalCode ,user, pass;
	private String reason= new String(), typePayment=new String (), codePaymentx=new String();
	private String communication=new String();
	private Server server=new Server ();
	private Integer amount;
	Socket socket;
    BufferedReader read;
    PrintWriter output;
	
	@Override
    public void initialize (final URL url, final ResourceBundle rb) {
		
		communicationPayment.setText(communication);
		try {
			socket = new Socket("localhost", 9091);
			output = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()));
			read = new BufferedReader(new InputStreamReader(socket.getInputStream()));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@FXML
	public void getTypePayment (ActionEvent event)  throws IOException
	{ 
		
		if(creditCardRB.isSelected()) {
			typePayment= creditCardRB.getText();
			
		}
		else if(ibanRB.isSelected()){
			typePayment=ibanRB.getText();
		}
		
	}
	
	public void setMember (String namex, String surnamex, String addressx, String fiscalCodex, String userx, String passx) {
		name=namex;
		surname=surnamex;
		address=addressx;
		fiscalCode=fiscalCodex;
		user=userx;
		pass=passx;
		
		
	}
	
	public void setCommunication(String communicationx) {
		communication=communicationx;
	}
	
	public void setAmount(int amountx) {
		amount= amountx;
	}
	
	public void setReason (String reasonx) {
		reason=reasonx;
	}
	
	@FXML
    void close(ActionEvent event) 
    {
    	Stage currentStage = (Stage)((Node) event.getSource()).getScene().getWindow();
		currentStage.close();
    }
    
	
	@FXML
	public void yesButtonPress(ActionEvent event) throws IOException {
		boolean a= false, b=false;
		codePaymentx=codePayment.getText();
		if (typePayment.equals("credit card") || typePayment.equals("iban")) {
			a=true;
		}
		if(codePaymentx.length()==10) {
			b=true;
		}
		if(a && b ) {
			communicationErrorPayment.setText("");
			server.addMember(name, surname, address, fiscalCode, user, pass);
			server.addPaymentRegistration(user, amount, reason, typePayment, codePaymentx);
			this.close(event);
		}
		else {
			communicationErrorPayment.setText("Complete correctly all fields!");
		}
	}
	

}
