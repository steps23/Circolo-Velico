package application;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.URL;
import java.net.UnknownHostException;
import java.text.ParseException;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.stage.Stage;
import javafx.scene.Node;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import classes.Server;

public class MemberMenuSC implements Initializable{

	
	private Member member;
	private Server server=new Server ();
	private boolean isExpiredRegistration, memberHaveExpiredBoat;
	Socket socket;
    BufferedReader read;
    PrintWriter output;
	
	@FXML
	private Label communicationLabel, communicationLabel2,infoLabel;
	
	public MemberMenuSC (Member memberx) throws ParseException, UnknownHostException, IOException {
		super();
		this.member=memberx;
		this.isExpiredRegistration= server.isExpiredRegistration(this.member.getIdmember());
		this.memberHaveExpiredBoat= server.memberHaveExpiredBoat(this.member.getIdmember());
		socket = new Socket("localhost", 9091);
		output = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()));
		read = new BufferedReader(new InputStreamReader(socket.getInputStream()));
	}
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		infoLabel.setText("Hello "+member.getName()+" your registration expity date is: "+member.getExpiryDate());
		if(isExpiredRegistration) {
			communicationLabel.setText("Dear "+ member.getName()+" you need to renew your registration");
		}
		if(memberHaveExpiredBoat) {
			communicationLabel2.setText("Dear "+ member.getName()+" you need to renew your boat/s storage");
		}
	}
	
	@FXML
    void back(ActionEvent event) throws IOException {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("ControlPanelMenu.fxml")); // load the file
		ControlPanelMenuSC newController= new ControlPanelMenuSC(member); // create the controller
    	loader.setController(newController); // set the controller of the loader
    	Parent newRoot= loader.load();
    	Scene newScene = new Scene(newRoot); // create the scene with the root
    	Stage currentStage = (Stage)((Node) event.getSource()).getScene().getWindow();
    	currentStage.setScene(newScene);// set the stage with the scene
    	currentStage.show();
    }

	@FXML
	public void boatMenuPressed (ActionEvent event)  throws IOException, ParseException
	{ 
		//System.out.println(member.getAddress());
		//Pyament+Member,Boat+Member, Registration+Boat+Competition,
		FXMLLoader loader = new FXMLLoader(getClass().getResource("BoatMenu.fxml")); // load the file
    	BoatMenuSC newController= new BoatMenuSC(member); // create the controller
    	//newController.setMember(member);
    	loader.setController(newController); // set the controller of the loader
    	Parent newRoot= loader.load();
    	Scene newScene = new Scene(newRoot); // create the scene with the root
    	Stage currentStage = (Stage)((Node) event.getSource()).getScene().getWindow();
    	currentStage.setScene(newScene);// set the stage with the scene
    	currentStage.show();
	}
	
    @FXML
    void renewRegistration(ActionEvent event) throws ParseException, IOException {
    	if(isExpiredRegistration) {
    		FXMLLoader loader = new FXMLLoader(getClass().getResource("PaymentNoPopMenu.fxml")); // load the file
    		PaymentRegistrationSC newController= new PaymentRegistrationSC(member); // create the controller
        	//newController.setMember(member);
        	loader.setController(newController); // set the controller of the loader
        	Parent newRoot= loader.load();
        	Scene newScene = new Scene(newRoot); // create the scene with the root
        	Stage currentStage = (Stage)((Node) event.getSource()).getScene().getWindow();
        	currentStage.setScene(newScene);// set the stage with the scene
        	currentStage.show();
    	}
    	else {
    		
    	}
    }

	@FXML
	public void competitionMenuPressed (ActionEvent event)  throws IOException
	{ 
		if(!isExpiredRegistration) {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("CompetitionMenu.fxml")); // load the file
			CompetitionMenuSC newController= new CompetitionMenuSC(member); // create the controller
        	loader.setController(newController); // set the controller of the loader
        	Parent newRoot= loader.load();
        	Scene newScene = new Scene(newRoot); // create the scene with the root
        	Stage currentStage = (Stage)((Node) event.getSource()).getScene().getWindow();
        	currentStage.setScene(newScene);// set the stage with the scene
        	currentStage.show();
		}
		else {
			
		}
	}
	

    @FXML
    void myRegistrationPressed(ActionEvent event) throws IOException {
    	FXMLLoader loader = new FXMLLoader(getClass().getResource("RaceRegistrationMenu.fxml")); // load the file
    	RaceRegistrationMenuSC newController= new RaceRegistrationMenuSC(member); // create the controller
    	loader.setController(newController); // set the controller of the loader
    	Parent newRoot= loader.load();
    	Scene newScene = new Scene(newRoot); // create the scene with the root
    	Stage currentStage = (Stage)((Node) event.getSource()).getScene().getWindow();
    	currentStage.setScene(newScene);// set the stage with the scene
    	currentStage.show();
    }


	
	
}

