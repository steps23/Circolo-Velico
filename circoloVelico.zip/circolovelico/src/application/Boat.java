package application;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import classes.Server;

/**
 * The boat object 
 * 
 * 
 * @author 		Stefano Ruggiero stefano.ruggiero@studenti.unipr.it mat.305880
 * @author		Chiara Piroli chiara.piroli1@studenti.unipr.it mat.308102
 * 
 * @version 	1.0
 * @since  		1.0
 *
 */

public class Boat {

		private final int idboat;
		private String name;
		private int length;
		private String date;
		private int active;
		private final int idMemberProp;
		
		/**
		 * Creates the boat with the parameters
		 * 
		 * @param idboat
		 * @param name
		 * @param length
		 * @param date
		 * @param active
		 * @param idMemberProp
		 */
		
		public Boat(int idboat, String name, int length, String date, int active, int idMemberProp) {
			super();
			this.idboat = idboat;
			this.name = name;
			this.length = length;
			this.date = date;
			this.active = active;
			this.idMemberProp = idMemberProp;
		}

		/**
		 * return if the boat is active or not
		 * 
		 * @return
		 */
		
		public int getActive() {
			return active;
		}
		
		/**
		 * change the status of the boat
		 * 
		 * @param active
		 */

		public void setActive(int active) {
			this.active = active;
		}
		
		/**
		 * return the name of the boat
		 * 
		 * @return
		 */

		public String getName() {
			return name;
		}
		
		/**
		 * set the name of the boat
		 * 
		 * @param name
		 */
		
		public void setName(String name) {
			this.name = name;
		}
		
		/**
		 * return the lenght of the boat
		 * 
		 * @return
		 */
		
		public int getLength() {
			return length;
		}
		
		/**
		 * set the length of the boat
		 * 
		 * @param length
		 */
		
		public void setLength(int length) {
			this.length = length;
		}
		
		/**
		 * return the store expiry date  of the boat
		 * 
		 * @return
		 */
		
		public String getDate() {
			return date;
		}
		
		/**
		 * set the store expiry date of the boat
		 * 
		 * @param date
		 */
		
		public void setDate(String date) {
			this.date = date;
		}
		
		/**
		 * return the id of the boat
		 * 
		 * @return
		 */
		
		public int getIdboat() {
			return idboat;
		}
		
		/**
		 * return the id of the boat's owner
		 * 
		 * @return
		 */
		
		public int getIdMemberProp() {
			return idMemberProp;
		}
		
		/**
		 * return the name of the owner
		 * 
		 * @return
		 */
		
		public String getNameProp() {
			Server server= new Server();
			String name=server.getNameMemberFromId(idMemberProp);
			return name;
		}
		
		/**
		 * return if the storage is expired or not
		 * 
		 * @return
		 * @throws ParseException
		 */
		
		public boolean storageIsExpired() throws ParseException {
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			Date dateNow = new Date();
			Date date = formatter.parse(this.date);
			if(dateNow.after(date)) {
				return true;
			}
			else {
				return false;
			}
		}
		
	
}
