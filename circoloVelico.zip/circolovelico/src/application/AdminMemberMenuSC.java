package application;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ResourceBundle;

import classes.Server;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

public class AdminMemberMenuSC implements Initializable {
	
    @FXML
    private TableColumn<Member, String> addressColumn;

    @FXML
    private TableColumn<Member, String> expiryDateColumn;

    @FXML
    private TableColumn<Member, String> fiscalCodeColumn;

    @FXML
    private TableColumn<Member, Integer> idMemberColumn;

    @FXML
    private TableView<Member> membersTable;

    @FXML
    private TableColumn<Member, String> nameColumn;

    @FXML
    private TableColumn<Member, String> surnameColumn;

    @FXML
    private TableColumn<Member, Integer> typeColumn;
    
    @FXML
    private ObservableList<Member> members= FXCollections.observableArrayList();
    
    private Server server= new Server();
    private Member member,memberClicked;
    Socket socket;
    BufferedReader read;
    PrintWriter output;
    
    public AdminMemberMenuSC (Member memberx) throws UnknownHostException, IOException {
    	this.member=memberx;
    	socket = new Socket("localhost", 9091);
		output = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()));
		read = new BufferedReader(new InputStreamReader(socket.getInputStream()));
    }
    

    @FXML
    void rowClicked(MouseEvent event) {
    	memberClicked= membersTable.getSelectionModel().getSelectedItem();
    }

    @FXML
    void back(ActionEvent event) throws IOException {
    	FXMLLoader loader = new FXMLLoader(getClass().getResource("AdministrationMenu.fxml")); // load the file
		AdministrationMenuSC newController= new AdministrationMenuSC(member); // create the controller
    	loader.setController(newController); // set the controller of the loader
    	Parent newRoot= loader.load();
    	Scene newScene = new Scene(newRoot); // create the scene with the root
    	Stage currentStage = (Stage)((Node) event.getSource()).getScene().getWindow();
    	currentStage.setScene(newScene);// set the stage with the scene
    	currentStage.show();
    }
    
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		server.addAllMembersToObsList(members);
		idMemberColumn.setCellValueFactory(new PropertyValueFactory<Member,Integer>("idmember"));
		nameColumn.setCellValueFactory(new PropertyValueFactory<Member,String>("name"));
		surnameColumn.setCellValueFactory(new PropertyValueFactory<Member,String>("lastname"));
		addressColumn.setCellValueFactory(new PropertyValueFactory<Member,String>("address"));
		fiscalCodeColumn.setCellValueFactory(new PropertyValueFactory<Member,String>("fiscalCode"));
		typeColumn.setCellValueFactory(new PropertyValueFactory<Member,Integer>("type"));
		expiryDateColumn.setCellValueFactory(new PropertyValueFactory<Member,String>("expiryDate"));
		membersTable.getItems().addAll(members);
	}
	
    @FXML
    void givePermissions(ActionEvent event) {
    	if (memberClicked != null && memberClicked.getType()== 3 ) {
			 server.giveStaffPermissions(memberClicked.getIdmember());
			 members.clear();
			 server.addAllMembersToObsList(members);
			 membersTable.setItems(members);
			 membersTable.refresh();
		 }
    }

    @FXML
    void removePermissions(ActionEvent event) {
    	if (memberClicked != null && memberClicked.getType()== 2 ) {
			 server.removeStaffPermissions(memberClicked.getIdmember());
			 members.clear();
			 server.addAllMembersToObsList(members);
			 membersTable.setItems(members);
			 membersTable.refresh();
    	}
    }
	
	

}
