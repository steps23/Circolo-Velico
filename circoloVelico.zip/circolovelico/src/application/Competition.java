package application;

/**
 * The competition object
 * 
 * 
 * @author 		Stefano Ruggiero stefano.ruggiero@studenti.unipr.it mat.305880
 * @author		Chiara Piroli chiara.piroli1@studenti.unipr.it mat.308102
 * 
 * @version 	1.0
 * @since  		1.0
 *
 */

public class Competition {
	
	private final int idcompetition;
	private String name;
	private String date;
    private final int idMemberOrg;
    
    /**
     * Creates the competition object
     * 
     * @param idcompetition
     * @param name
     * @param date
     * @param idMemberOrg
     */
    
    
	public Competition(int idcompetition, String name, String date, int idMemberOrg) {
		super();
		this.idcompetition = idcompetition;
		this.name = name;
		this.date = date;
		this.idMemberOrg = idMemberOrg;
	}


	/**
	 * return the name of the competition
	 * 
	 * @return
	 */

	public String getName() {
		return name;
	}
	
	/**
	 * set the name of the competition
	 * 
	 * @param name
	 */

	public void setName(String name) {
		this.name = name;
	}

	/**
	 * get the date of the competition
	 * 
	 * @return
	 */

	public String getDate() {
		return date;
	}


	/**
	 * set the date of the competition
	 * 
	 * @param date
	 */
	
	public void setDate(String date) {
		this.date = date;
	}

	/**
	 * return id the competition
	 * 
	 * @return
	 */

	public int getIdcompetition() {
		return idcompetition;
	}


	/**
	 * return the id of the member that have organized the competition
	 * 
	 * @return
	 */
	
	public int getIdMemberOrg() {
		return idMemberOrg;
	}

    
    
    
    
}
