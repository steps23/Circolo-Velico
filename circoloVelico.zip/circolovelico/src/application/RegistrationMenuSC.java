package application;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import classes.Server;
import javafx.fxml.Initializable;
//import org.controlsfx.control.Notifications;


public class RegistrationMenuSC implements Initializable {

	private Scene scene;
	private Parent root;
	
	@FXML
	private TextField nameInput;
	
	@FXML
	private TextField lastnameInput;
	
	@FXML
	private TextField addressInput;
	
	@FXML
	private TextField fiscalCodeInput;
	
	@FXML
	private TextField userInput;
	
	@FXML
	private TextField passInput;
	
	@FXML
	private Label communicationRegistrationMenu;
	
	Server server=new Server ();
	
	Socket socket;
    BufferedReader read;
    PrintWriter output;
	
	@FXML
	public void addMember(ActionEvent event)  throws IOException
	{ 
		//communicationRegistrationMenu= getCommunicationRegistrationMenu();
		String name = nameInput.getText();
		String lastname = lastnameInput.getText();
		String address = addressInput.getText();
		String fiscalCode = fiscalCodeInput.getText();
		String username = userInput.getText();
		String password = passInput.getText();
		if (name.length()>0 && lastname.length()>0 && address.length()>3 && 
				fiscalCode.length()==16 && username.length()>0 && password.length()>0) {
			if(server.userIsPresent(username)) {
				
				
				/*Notification.create()
					.title ("Error")
					.text ("Username already exist!")
					.showWarning();*/
				communicationRegistrationMenu.setText("Error, username already exist");
			}
			else {
				//server.addMember(name, lastname, address, fiscalCode, username, password);
				FXMLLoader loader = new FXMLLoader(getClass().getResource("PaymentPopMenu.fxml")); // load the file
            	PaymentNewRegistrationPopMenuSC popController= new PaymentNewRegistrationPopMenuSC(); // create the controller
            	popController.setMember(name, lastname, address, fiscalCode, username, password);
            	popController.setAmount(150);
            	popController.setReason("registration");
            	popController.setCommunication("Per procedere con la registrazione è necessaria una quota di 150 euro");
            	loader.setController(popController); // set the controller of the loader
            	Parent popRoot= loader.load(); //create the root of the loader
            	Scene popScene = new Scene(popRoot); // create the scene with the root
            	Stage popMenu= new Stage(); // create the stage
        		popMenu.setScene(popScene);// set the stage with the scene
        		popMenu.showAndWait();
			}
		
		}
		else {
			communicationRegistrationMenu.setText("Error, incorrect input");
		}
	}
	

	@FXML
	public void back(ActionEvent event)  throws IOException
	{
		root = FXMLLoader.load(getClass().getResource("MainMenu.fxml"));
		Stage currentStage = (Stage)((Node) event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		currentStage.setScene(scene);
		currentStage.show();

	}
	@Override
    public void initialize (final URL url, final ResourceBundle rb) {
		try {
			socket = new Socket("localhost", 9091);
			output = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()));
			read = new BufferedReader(new InputStreamReader(socket.getInputStream()));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	

	
	
}
