package application;


/**
 * The member object
 * 
 * 
 * @author 		Stefano Ruggiero stefano.ruggiero@studenti.unipr.it mat.305880
 * @author		Chiara Piroli chiara.piroli1@studenti.unipr.it mat.308102
 * 
 * @version 	1.0
 * @since  		1.0
 *
 */

public class Member {

	
	private final int idmember;
	private String name;
	private String lastname;
	private String address;
	private String fiscalCode;
	private int type;
	private String expiryDate;
	private String username;
	private String password;
	
	
	/**
	 * Creates the member object with the parameters
	 * 
	 * @param idmember
	 * @param name
	 * @param lastname
	 * @param address
	 * @param fiscalCode
	 * @param type
	 * @param expiryDate
	 * @param username
	 * @param password
	 */
	public Member(int idmember, String name, String lastname, String address, String fiscalCode, int type,
			String expiryDate, String username, String password) {
		super();
		this.idmember = idmember;
		this.name = name;
		this.lastname = lastname;
		this.address = address;
		this.fiscalCode = fiscalCode;
		this.type = type;
		this.expiryDate = expiryDate;
		this.username = username;
		this.password = password;
	}
	
	/**
	 * 
	 * return the name of the member
	 * 
	 * @return
	 */
	
	public String getName() {
		return name;
	}
	
	/**
	 * set the name of the member
	 * 
	 * @param name
	 */
	
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * return the last name of the member
	 * 
	 * @return
	 */
	
	public String getLastname() {
		return lastname;
	}
	
	/**
	 * set the last name of the member
	 * 
	 * @param lastname
	 */
	
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	
	/**
	 * return the address of the member
	 * 
	 * @return
	 */
	
	public String getAddress() {
		return address;
	}
	
	/**
	 * set the address of the member
	 * 
	 * @param address
	 */
	
	public void setAddress(String address) {
		this.address = address;
	}
	
	/**
	 * return the fiscal code of the member
	 * 
	 * @return
	 */
	
	public String getFiscalCode() {
		return fiscalCode;
	}
	
	/**
	 * set the fiscal code of the member
	 * 
	 * @param fiscalCode
	 */
	
	public void setFiscalCode(String fiscalCode) {
		this.fiscalCode = fiscalCode;
	}
	
	/**
	 * return the type of the member
	 * 
	 * @return
	 */
	
	public int getType() {
		return type;
	}
	
	/**
	 * set the type of the member
	 * 
	 * @param type
	 */
	
	public void setType(int type) {
		this.type = type;
	}
	
	/**
	 * return the registration exipiry date of the member
	 * 
	 * @return
	 */
	
	public String getExpiryDate() {
		return expiryDate;
	}
	
	/**
	 * set the registration expiry date of the member
	 * 
	 * @param expiryDate
	 */
	
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	
	/**
	 * return the username of the member
	 * 
	 * @return
	 */
	
	public String getUsername() {
		return username;
	}
	
	/**
	 * set the username of the member
	 * 
	 * @param username
	 */
	
	public void setUsername(String username) {
		this.username = username;
	}
	
	/**
	 * return the password of the member
	 * 
	 * @return
	 */
	
	public String getPassword() {
		return password;
	}
	
	/**
	 * set the password of the member
	 * 
	 * @param password
	 */
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	/**
	 * return the id of the member
	 * 
	 * @return
	 */
	
	public int getIdmember() {
		return idmember;
	}
	
		
	
	
}
