package application;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ResourceBundle;

import classes.Server;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

public class AdminBoatMenuSC implements Initializable {

    @FXML
    private TableColumn<Boat, String> dateColumn;

    @FXML
    private TableColumn<Boat, Integer> lengthColumn;

    @FXML
    private TableColumn<Boat, String> nameColumn;
    
    @FXML
    private TableColumn<Boat, Integer> idColumn;
    
    @FXML
    private TableColumn<Boat, Integer> activeColumn;
    

    @FXML
    private TableColumn<Boat, String> namePropColumn;
    
    @FXML
    private TableColumn<Boat, Integer> idMemberPropColumn;

    @FXML
    private TableView<Boat> boatsTable;
    
    @FXML
    private Label communicationLabel;
    
    @FXML
    private ObservableList<Boat> boats= FXCollections.observableArrayList();
    
    private Server server=new Server ();
    private Member member;
    private Boat boatClicked;
    
    Socket socket;
    BufferedReader read;
    PrintWriter output;
   
    public AdminBoatMenuSC(Member memberx) throws UnknownHostException, IOException {
		super();
		this.member= memberx;
		socket = new Socket("localhost", 9091);
		output = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()));
		read = new BufferedReader(new InputStreamReader(socket.getInputStream()));
	}
    
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		server.addAllBoatToObsList(boats);
		nameColumn.setCellValueFactory(new PropertyValueFactory<Boat, String>("name"));
		lengthColumn.setCellValueFactory(new PropertyValueFactory<Boat, Integer>("length"));
		dateColumn.setCellValueFactory(new PropertyValueFactory<Boat, String>("date"));
		idColumn.setCellValueFactory(new PropertyValueFactory<Boat, Integer>("idboat"));
		activeColumn.setCellValueFactory(new PropertyValueFactory<Boat, Integer>("active"));
		namePropColumn.setCellValueFactory(new PropertyValueFactory<Boat, String>("nameProp"));
		idMemberPropColumn.setCellValueFactory(new PropertyValueFactory<Boat, Integer>("idMemberProp"));
		boatsTable.getItems().addAll(boats);
	}
	
	@FXML
    void rowClicked(MouseEvent event) {
		boatClicked= boatsTable.getSelectionModel().getSelectedItem();
		//System.out.println(boatClicked.getIdboat());
    }
	
	@FXML
    void removeBoat(ActionEvent event) {
		 if (boatClicked != null) {
			 communicationLabel.setText("");
			 server.removeBoat(boatClicked.getIdboat());
			 boats.clear();
			 server.addAllBoatToObsList(boats);
			 boatsTable.setItems(boats);
			 boatsTable.refresh();
		 }
		 else {
			 communicationLabel.setText("Please select a boat");
		 }
    }
	
    @FXML
    void renewExpiry(ActionEvent event) {
    	if (boatClicked != null) {
    		communicationLabel.setText("");
			 server.storeBoat(boatClicked.getIdboat());
			 boats.clear();
			 server.addAllBoatToObsList(boats);
			 boatsTable.setItems(boats);
			 boatsTable.refresh();
		 }
    	 else {
			 communicationLabel.setText("Please select a boat");
		 }
    }
    
    @FXML
    void back(ActionEvent event) throws IOException {
    	FXMLLoader loader = new FXMLLoader(getClass().getResource("AdministrationMenu.fxml")); // load the file
		AdministrationMenuSC newController= new AdministrationMenuSC(member); // create the controller
    	loader.setController(newController); // set the controller of the loader
    	Parent newRoot= loader.load();
    	Scene newScene = new Scene(newRoot); // create the scene with the root
    	Stage currentStage = (Stage)((Node) event.getSource()).getScene().getWindow();
    	currentStage.setScene(newScene);// set the stage with the scene
    	currentStage.show();
    }
}
