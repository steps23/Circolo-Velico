package test;

import application.Payment;

import static org.junit.Assert.*;

import org.junit.Test;

public class PaymentTest {
	private Payment instance= new Payment(1,1,1,"prova","prova","prova");
	
	@Test
	public void testIdPayment() {
		int  expResult = 1;
        int result = instance.getIdpayment();
        //System.out.println(result);
        assertEquals(expResult, result);
	}
	
	@Test
	public void testIdMemberPay() {
		int  expResult = 1;
        int result = instance.getIdMemberPay();
        //System.out.println(result);
        assertEquals(expResult, result);
	}
	
	@Test
	public void testAmount() {
		int  expResult = 1;
        int result = instance.getAmount();
        //System.out.println(result);
        assertEquals(expResult, result);
	}
	
	@Test
	public void testSetAmount() {
		int newAmount=2;
		int  expResult = newAmount;
		instance.setAmount(newAmount);
        int result = instance.getAmount();
        //System.out.println(result);
        assertEquals(expResult, result);
	}
	
	@Test
	public void testReason() {
		String expResult="prova";
		String result = instance.getReason();
		assertEquals(expResult, result);
	}
	
	@Test
	public void testSetReason() {
		String newReason="newProva";
		String expResult=newReason;
		instance.setReason(newReason);
		String result = instance.getReason();
		assertEquals(expResult, result);
	}
}
