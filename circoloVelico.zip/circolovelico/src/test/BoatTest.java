package test;

import application.Boat;

import static org.junit.Assert.*;

import org.junit.Test;


public class BoatTest {
	
	private Boat instance = new Boat(111,"Prova",222,"2022-2-2",1,1);


    @Test
    public void testIdBoat() 
    {
        
        int  expResult = 111;
        int result = instance.getIdboat();
        //System.out.println(result);
        assertEquals(expResult, result);
    }
    
    @Test
    public void testName() 
    {
        
        String  expResult = "Prova";
        String result = instance.getName();
        //System.out.println(result);
        assertEquals(expResult, result);
    }
    
    
    @Test
    public void testSetName() 
    {
        String newName= "newProva";
        instance.setName(newName);
        String  expResult = newName;
        String result = instance.getName();
        //System.out.println(result);
        assertEquals(expResult, result);
    }
    
    @Test
    public void testLength() 
    {
        int  expResult = 222;
        int result = instance.getLength();
        //System.out.println(result);
        assertEquals(expResult, result);
    }
    
    @Test
    public void testActive() 
    {
        int  expResult = 1;
        int result = instance.getActive();
        //System.out.println(result);
        assertEquals(expResult, result);
    }
    
    @Test
    public void testSetActive() 
    {
        int newActive= 0;
        instance.setActive(newActive);
        int  expResult = newActive;
        int result = instance.getActive();
        //System.out.println(result);
        assertEquals(expResult, result);
    }
    

}
