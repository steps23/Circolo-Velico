package test;

import application.Registration;

import static org.junit.Assert.*;

import org.junit.Test;

public class RegistrationTest {
	
	private Registration instance = new Registration(1,1,1,1);
	
	@Test
	public void testIdRegistration() {
		int  expResult = 1;
        int result = instance.getIdregistration();
        //System.out.println(result);
        assertEquals(expResult, result);
	}
	
	@Test
	public void testIdMemberReg() {
		int  expResult = 1;
        int result = instance.getIdMemberReg();
        //System.out.println(result);
        assertEquals(expResult, result);
	}
	
	@Test
	public void testIdBoatReg() {
		int  expResult = 1;
        int result = instance.getIdBoatReg();
        //System.out.println(result);
        assertEquals(expResult, result);
	}
	
	@Test
	public void testIdCompetitionReg() {
		int  expResult = 1;
        int result = instance.getIdCompetitionReg();
        //System.out.println(result);
        assertEquals(expResult, result);
	}
	
}
