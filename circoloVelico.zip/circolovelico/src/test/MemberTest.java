package test;

import application.Member;

import static org.junit.Assert.*;

import org.junit.Test;

public class MemberTest {
	
	private Member instance= new Member(1,"prova","prova","prova","prova",1,"2022-2-2","prova","prova");
	
	@Test
    public void testIdMember() 
    {
        
        int  expResult = 1;
        int result = instance.getIdmember();
        //System.out.println(result);
        assertEquals(expResult, result);
    }

	@Test
	public void testName() {
		String expResult="prova";
		String result = instance.getName();
		assertEquals(expResult, result);
	}
	
	@Test
	public void testSetName(){
		String newName= "newProva";
		String expResult=newName;
		instance.setName(newName);
		String result = instance.getName();
		assertEquals(expResult, result);
	}
	
	@Test
	public void testType() {
		int  expResult = 1;
        int result = instance.getType();
        //System.out.println(result);
        assertEquals(expResult, result);
	}
	
	@Test
	public void testSetType() {
		int newType=2;
		int  expResult = newType;
		instance.setType(newType);
        int result = instance.getType();
        //System.out.println(result);
        assertEquals(expResult, result);
	}
	
	
}
