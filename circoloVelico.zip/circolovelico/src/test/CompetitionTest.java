package test;

import application.Competition;

import static org.junit.Assert.*;

import org.junit.Test;

public class CompetitionTest {
	
	private Competition instance = new Competition(1,"Prova","2022-2-2",11);
	
	@Test
    public void testIdCompetition() 
    {
        
        int  expResult = 1;
        int result = instance.getIdcompetition();
        //System.out.println(result);
        assertEquals(expResult, result);
    }
	
	@Test
    public void testName() 
    {
        
        String  expResult = "Prova";
        String result = instance.getName();
        //System.out.println(result);
        assertEquals(expResult, result);
    }
	
	@Test
    public void testSetName() 
    {
        String newName= "newProva";
        instance.setName(newName);
        String  expResult = newName;
        String result = instance.getName();
        //System.out.println(result);
        assertEquals(expResult, result);
    }
	
	@Test
    public void testIdMemberOrg() 
    {
        int  expResult = 11;
        int result = instance.getIdMemberOrg();
        //System.out.println(result);
        assertEquals(expResult, result);
    }

}
