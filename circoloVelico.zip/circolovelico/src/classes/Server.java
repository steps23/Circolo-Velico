package classes;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import application.Boat;
import application.Competition;
import application.Member;
import application.Payment;
import application.Registration;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javafx.collections.ObservableList;


public class Server {

	
	private static String URL="jdbc:mysql://localhost:3306/circolovelico";
	private static String USERNAME="root";
	private static String PASSWORD="1234";
	
	static ServerSocket serversocket;
	static Socket client;
    BufferedReader input;
    PrintWriter output;
    
 
	
	public Member sendQuery (String user, String pass) {
		Member member= null;
		try {
			Connection connection = DriverManager.getConnection(URL,USERNAME,PASSWORD);
			//System.out.println("Connected");
			
			String query = "SELECT * FROM member ";
			Statement statement = connection.createStatement();
			ResultSet result =statement.executeQuery(query);
			while (result.next()) {
				String U = result.getString("username"); //possiamo usare sia l'indice che il nome della colonna
				String P = result.getString("password");
				if (user.equals(U) && pass.equals(P)) {
					System.out.println("ok"+ " "+ U);
					member=new Member(Integer.parseInt(result.getString("idMember")), result.getString("name"), result.getString("surname"), result.getString("address")
							, result.getString("fiscalCode"),Integer.parseInt( result.getString("type")), result.getString("expiryDate"), U, P);
					
					break;
					
				}
			}
			//System.out.println("errore username o password sbagliata");
			
			connection.close();
			
			
		}catch (SQLException e) {
			System.out.println("Connection error");
			e.printStackTrace();
			
		}
		return member;
	}
	
	
	
	public boolean userIsPresent(String user) {
		try {
			Connection connection = DriverManager.getConnection(URL,USERNAME,PASSWORD);
			//System.out.println("Connected");
			
			String query = "SELECT username FROM member ";
			Statement statement = connection.createStatement();
			ResultSet result =statement.executeQuery(query);
			while (result.next()) {
				String U = result.getString("username"); //possiamo usare sia l'indice che il nome della colonna
				if (user.equals(U) ) {
					//System.out.println("ok");
					return true;
				}
			}
			
			//System.out.println("errore username o password sbagliata");
			
			connection.close();
			return false;
			
		}catch (SQLException e) {
			System.out.println("Connection error");
			e.printStackTrace();
			return true;
		}

	}
	
	
	public void addMember (String name, String surname, String address, String fiscalCode, String user, String pass) {
		if (!this.userIsPresent(user)) {
			try {
				Connection connection = DriverManager.getConnection(URL,USERNAME,PASSWORD);
				//System.out.println("Connected");
				
				// inserimento riga in tabella
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd "); 
			    LocalDateTime date = LocalDateTime.now();  
			    date = date.plusYears(1);
			    //System.out.println(formatter.format(date));
			    
				String sql = "INSERT INTO member (name,surname, address, fiscalCode,type, expiryDate, username,password ) VALUES (?,?,?,?,?,?,?,?)";
				
				PreparedStatement statement = connection.prepareStatement(sql);
				statement.setString(1, name);
				statement.setString(2, surname);
				statement.setString(3, address);
				statement.setString(4, fiscalCode);
				statement.setString(5, "3");
				statement.setString(6, formatter.format(date));
				statement.setString(7, user);
				statement.setString(8, pass);
				statement.executeUpdate();
				
				statement.close();
				connection.close();
				
			}catch (SQLException e) {
				System.out.println("Connection error");
				e.printStackTrace();
				
			}
		}
		else {
			System.out.println("user already exist!");
		}
	}
	
	public void updateDateMember(Member member) {
		try {
			Connection connection = DriverManager.getConnection(URL,USERNAME,PASSWORD);
			//System.out.println("Connected");
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd "); 
		    LocalDateTime date = LocalDateTime.now();  
		    date = date.plusYears(1);
		    String dateString= formatter.format(date);
		    member.setExpiryDate(dateString);
		    String query = "UPDATE member SET expiryDate=? WHERE idMember=?";
			
			PreparedStatement statement = connection.prepareStatement(query);
			
			statement.setString(1, dateString);
			statement.setInt(2, member.getIdmember());
			
			//System.out.println(statement);
			
			statement.executeUpdate();
			
			statement.close();
			connection.close();
			
		}catch (SQLException e) {
			System.out.println("Connection error");
			e.printStackTrace();
			
		}
	}
	
	public String findIdByUsername(String user)  {
		String idMember=new String ();
		try {
		Connection connection = DriverManager.getConnection(URL,USERNAME,PASSWORD);
		//System.out.println("Connected");
		
		String query = "SELECT idMember FROM member WHERE username=?";
		PreparedStatement statement = connection.prepareStatement(query);
		
		statement.setString(1, user);
		ResultSet result = statement.executeQuery();
		result.next();
		
		idMember= result.getString("idMember");
		//System.out.println(idMember);
		statement.close();
		connection.close();
		
		}catch (SQLException e) {
			System.out.println("Connection error");
			e.printStackTrace();
		}
		return idMember;
	}
	
	public void addPaymentRegistration(String user, int amount, String reason, String typePayment, String codePayment ) {
		try {
			Connection connection = DriverManager.getConnection(URL,USERNAME,PASSWORD);
			//System.out.println("Connected");
			String idMemberPay= new String (this.findIdByUsername(user));
		    
			String sql = "INSERT INTO payment (idMemberPay, amount, reason, typePayment, codePayment ) VALUES (?,?,?,?,?)";
			
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setString(1, idMemberPay);
			statement.setInt(2,amount);
			statement.setString(3, reason);
			statement.setString(4, typePayment);
			statement.setString(5, codePayment);
			
			statement.executeUpdate();
			
			statement.close();
			connection.close();
			
		}catch (SQLException e) {
			System.out.println("Connection error");
			e.printStackTrace();
			
		}
	}
	
	public boolean isExpiredRegistration (int idMember) throws ParseException {
		boolean answer = false;
		try {
			Connection connection = DriverManager.getConnection(URL,USERNAME,PASSWORD);
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			Date dateNow = new Date();
			String query = "SELECT * FROM member WHERE idMember=?";
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setString(1, Integer.toString(idMember));
			ResultSet result = statement.executeQuery();
			result.next();
			String dateString= new String(result.getString("expiryDate"));
			Date date = formatter.parse(dateString);
			//System.out.println(dateString);
			if(dateNow.after(date)) {
				System.out.println("SCADUTO");
				answer=true;
			}
			else {
				System.out.println("NON SCADUTO");
			}
			connection.close();
			
		}catch (SQLException e) {
			System.out.println("Connection error");
			e.printStackTrace();
		}
		return answer;
	}
	
	public boolean memberHaveExpiredBoat (int idMember) throws ParseException {
		boolean answer = false;
		try {
			Connection connection = DriverManager.getConnection(URL,USERNAME,PASSWORD);
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			Date dateNow = new Date();
			String query = "SELECT * FROM boat WHERE idMemberProp=?";
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setString(1, Integer.toString(idMember));
			ResultSet result = statement.executeQuery();
			while(result.next()) {
				String dateString= new String(result.getString("expiryDate"));
				Date date = formatter.parse(dateString);
				//System.out.println(dateString);
				if(dateNow.after(date)) {
					System.out.println("BARCA SCADUTA");
					answer=true;
					return answer;
				}
				else {
					System.out.println("BARCA NON SCADUTA");
				}
			}
			connection.close();
			
		}catch (SQLException e) {
			System.out.println("Connection error");
			e.printStackTrace();
		}
		return answer;
	}
		
	public void addPersonalBoatToObsList (ObservableList<Boat> boats,int idMember) {
		try {
			Connection connection = DriverManager.getConnection(URL,USERNAME,PASSWORD);
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			String query = "SELECT * FROM boat WHERE idMemberProp=?";
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setString(1, Integer.toString(idMember));
			ResultSet result = statement.executeQuery();
			while (result.next()) {
				int idboat= Integer.parseInt(result.getString("idboat"));
				String name = result.getString("name");
				int length = Integer.parseInt(result.getString("length"));
				String expiryDate= result.getString("expiryDate");
				int active= Integer.parseInt(result.getString("active"));
				int idMemberProp = Integer.parseInt(result.getString("idMemberProp"));
				//if (active==1) {
					Boat boat= new Boat(idboat,name,length,expiryDate,active,idMemberProp);
					boats.add(boat);
				//}
			}
			connection.close();
			
		}catch (SQLException e) {
			System.out.println("Connection error");
			e.printStackTrace();
		}
	}
	
	public void addAllMembersToObsList (ObservableList<Member> members) {
		try {
			Connection connection = DriverManager.getConnection(URL,USERNAME,PASSWORD);
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			String query = "SELECT * FROM member ";
			PreparedStatement statement = connection.prepareStatement(query);
			ResultSet result = statement.executeQuery();
			while (result.next()) {
				int idMember = Integer.parseInt(result.getString("idMember"));
				String name = result.getString("name");
				String surname= result.getString("surname");
				String address = result.getString("address");
				String fiscalCode= result.getString("fiscalCode");
				int type = Integer.parseInt(result.getString("type"));
				String expiryDate = result.getString("expiryDate");
				String username = result.getString("username");
				String password = result.getString("password");
				Member member= new Member(idMember,name,surname,address,
						fiscalCode,type,expiryDate,username,password);
				members.add(member);
			}
			connection.close();
			
		}catch (SQLException e) {
			System.out.println("Connection error");
			e.printStackTrace();
		}
	}
	
	public void addAllBoatToObsList (ObservableList<Boat> boats) {
		try {
			Connection connection = DriverManager.getConnection(URL,USERNAME,PASSWORD);
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			String query = "SELECT * FROM boat ";
			PreparedStatement statement = connection.prepareStatement(query);
			ResultSet result = statement.executeQuery();
			while (result.next()) {
				int idboat= Integer.parseInt(result.getString("idboat"));
				String name = result.getString("name");
				int length = Integer.parseInt(result.getString("length"));
				String expiryDate= result.getString("expiryDate");
				int active= Integer.parseInt(result.getString("active"));
				int idMemberProp = Integer.parseInt(result.getString("idMemberProp"));
				//if (active==1) {
					Boat boat= new Boat(idboat,name,length,expiryDate,active,idMemberProp);
					boats.add(boat);
				//}
			}
			connection.close();
			
		}catch (SQLException e) {
			System.out.println("Connection error");
			e.printStackTrace();
		}
	}
	
	public void addPersonalGoodBoatToObsList (ObservableList<Boat> boats,int idMember) throws ParseException {
		try {
			Connection connection = DriverManager.getConnection(URL,USERNAME,PASSWORD);
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			String query = "SELECT * FROM boat WHERE idMemberProp=? AND active=1";
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setString(1, Integer.toString(idMember));
			ResultSet result = statement.executeQuery();
			while (result.next()) {
				int idboat= Integer.parseInt(result.getString("idboat"));
				String name = result.getString("name");
				int length = Integer.parseInt(result.getString("length"));
				String expiryDate= result.getString("expiryDate");
				int active= Integer.parseInt(result.getString("active"));
				int idMemberProp = Integer.parseInt(result.getString("idMemberProp"));
				//if (active==1) {
					Boat boat= new Boat(idboat,name,length,expiryDate,active,idMemberProp);
					if (!boat.storageIsExpired()) {
						boats.add(boat);
					//}
				}
			}
			connection.close();
			
		}catch (SQLException e) {
			System.out.println("Connection error");
			e.printStackTrace();
		}
	}
	
	public void addCompetitionToObsList(ObservableList<Competition> competitions) throws ParseException {
		try {
			
			Connection connection = DriverManager.getConnection(URL,USERNAME,PASSWORD);
			
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			Date dateNow = new Date();
			
			String query = "SELECT * FROM competition";
			PreparedStatement statement = connection.prepareStatement(query);
			ResultSet result = statement.executeQuery();
			while (result.next()) {
				int idcompetition = Integer.parseInt(result.getString("idcompetition"));
				String name = result.getString("name");
				String dateString= new String(result.getString("date"));
				Date date = formatter.parse(dateString);
				int idMemberOrg = Integer.parseInt(result.getString("idMemberOrg"));
				if(!dateNow.after(date)) {
					Competition comp= new Competition(idcompetition,name,dateString,idMemberOrg);
					competitions.add(comp);
				}
				
			}
			connection.close();
			
		}catch (SQLException e) {
			System.out.println("Connection error");
			e.printStackTrace();
		}
	}
	
	public void addPaymentsToObsList(ObservableList<Payment> payments) {
		try {
			
			Connection connection = DriverManager.getConnection(URL,USERNAME,PASSWORD);
			
			String query = "SELECT * FROM payment";
			PreparedStatement statement = connection.prepareStatement(query);
			ResultSet result = statement.executeQuery();
			while (result.next()) {
				int idpayment= Integer.parseInt(result.getString("idpayment"));
				int idMemberPay= Integer.parseInt(result.getString("idMemberPay"));
				int amount= Integer.parseInt(result.getString("amount"));
				String reason= result.getString("reason");
				String typePayment= result.getString("reason");
				String codePayment= result.getString("codePayment");
				Payment payment = new Payment(idpayment,idMemberPay,amount,reason,typePayment,codePayment);
				payments.add(payment);
			}
			connection.close();
			
		}catch (SQLException e) {
			System.out.println("Connection error");
			e.printStackTrace();
		}
	}
	
	public void addPersonalRegistrationToObsList (ObservableList<Registration> registrations,int idMember) {
		try {
			
			Connection connection = DriverManager.getConnection(URL,USERNAME,PASSWORD);
			
			String query = "SELECT circolovelico.registration.idregistration,circolovelico.registration.idMemberReg,circolovelico.registration.idCompetitionReg,circolovelico.registration.idBoatReg, circolovelico.boat.name,circolovelico.member.name, circolovelico.member.surname, circolovelico.competition.name,circolovelico.competition.date\r\n"
					+ "FROM circolovelico.registration,circolovelico.boat,circolovelico.member,circolovelico.competition \r\n"
					+ "WHERE idMemberReg=idMember \r\n"
					+ "AND idCompetitionReg=idcompetition \r\n"
					+ "AND idBoatReg=idboat\r\n"
					+ "AND idMember=?";
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setInt(1, idMember);
			ResultSet result = statement.executeQuery();
			while (result.next()) {
				result.getString("member.surname");
				int idregistration=Integer.parseInt(result.getString("idregistration"));
				int idMemberReg=Integer.parseInt(result.getString("idMemberReg"));
				int idBoatReg=Integer.parseInt(result.getString("idBoatReg"));
				int idCompetitionReg=Integer.parseInt(result.getString("idCompetitionReg"));
				String memberName=result.getString("member.name")+" " +result.getString("member.surname");
				String boatName=result.getString("boat.name");
				String competitionName=result.getString("competition.name");
				String competitionDate=result.getString("competition.date");
				Registration registration= new Registration(idregistration,idMemberReg,idBoatReg,idCompetitionReg,
						memberName,boatName,competitionName,competitionDate);
				registrations.add(registration);
			}
			connection.close();
			
		}catch (SQLException e) {
			System.out.println("Connection error");
			e.printStackTrace();
		}
	}
	
	public void addRegistrationToObsList (ObservableList<Registration> registrations) {
		try {
			
			Connection connection = DriverManager.getConnection(URL,USERNAME,PASSWORD);
			
			String query = "SELECT circolovelico.registration.idregistration,circolovelico.registration.idMemberReg,circolovelico.registration.idCompetitionReg,circolovelico.registration.idBoatReg, circolovelico.boat.name,circolovelico.member.name, circolovelico.member.surname, circolovelico.competition.name,circolovelico.competition.date\r\n"
					+ "FROM circolovelico.registration,circolovelico.boat,circolovelico.member,circolovelico.competition \r\n"
					+ "WHERE idMemberReg=idMember \r\n"
					+ "AND idCompetitionReg=idcompetition \r\n"
					+ "AND idBoatReg=idboat\r\n";
			PreparedStatement statement = connection.prepareStatement(query);
			ResultSet result = statement.executeQuery();
			while (result.next()) {
				result.getString("member.surname");
				int idregistration=Integer.parseInt(result.getString("idregistration"));
				int idMemberReg=Integer.parseInt(result.getString("idMemberReg"));
				int idBoatReg=Integer.parseInt(result.getString("idBoatReg"));
				int idCompetitionReg=Integer.parseInt(result.getString("idCompetitionReg"));
				String memberName=result.getString("member.name")+" " +result.getString("member.surname");
				String boatName=result.getString("boat.name");
				String competitionName=result.getString("competition.name");
				String competitionDate=result.getString("competition.date");
				Registration registration= new Registration(idregistration,idMemberReg,idBoatReg,idCompetitionReg,
						memberName,boatName,competitionName,competitionDate);
				registrations.add(registration);
			}
			connection.close();
			
		}catch (SQLException e) {
			System.out.println("Connection error");
			e.printStackTrace();
		}
	}
	
	public void giveStaffPermissions (int idMember) {
		try {
			Connection connection = DriverManager.getConnection(URL,USERNAME,PASSWORD);
			String query = "UPDATE member SET type=2 WHERE idMember=?";
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setInt(1, idMember);
			statement.executeUpdate();
			connection.close();
			
		}catch (SQLException e) {
			System.out.println("Connection error");
			e.printStackTrace();
		}
	}
	
	public void removeStaffPermissions (int idMember) {
		try {
			Connection connection = DriverManager.getConnection(URL,USERNAME,PASSWORD);
			String query = "UPDATE member SET type=3 WHERE idMember=?";
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setInt(1, idMember);
			statement.executeUpdate();
			connection.close();
			
		}catch (SQLException e) {
			System.out.println("Connection error");
			e.printStackTrace();
		}
	}
	
	public void removeBoat (int idboat) {
		try {
			Connection connection = DriverManager.getConnection(URL,USERNAME,PASSWORD);
			String query = "UPDATE boat SET active=0 WHERE idboat=?";
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setString(1, Integer.toString(idboat));
			statement.setInt(1, idboat);
			statement.executeUpdate();
			connection.close();
			
		}catch (SQLException e) {
			System.out.println("Connection error");
			e.printStackTrace();
		}
	}
	
	public void addNewBoat (String name,int length,int idMemberProp) {
		try {
			Connection connection = DriverManager.getConnection(URL,USERNAME,PASSWORD);
			//System.out.println("Connected");
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd "); 
		    LocalDateTime date = LocalDateTime.now();  
		    date = date.plusYears(1);
		    String dateString= formatter.format(date);
			String sql = "INSERT INTO boat (name, length, expiryDate, idMemberProp) VALUES (?,?,?,?)";
			
			PreparedStatement statement = connection.prepareStatement(sql);
			
			statement.setString(1, name);
			statement.setInt(2, length);
			statement.setString(3, dateString);
			statement.setInt(4, idMemberProp);
			
			//System.out.println(statement);
			
			statement.executeUpdate();
			
			statement.close();
			connection.close();
			
		}catch (SQLException e) {
			System.out.println("Connection error");
			e.printStackTrace();
			
		}
	}
	
	public void storeBoat(int idboat) {
		try {
			Connection connection = DriverManager.getConnection(URL,USERNAME,PASSWORD);
			//System.out.println("Connected");
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd "); 
		    LocalDateTime date = LocalDateTime.now();  
		    date = date.plusYears(1);
		    String dateString= formatter.format(date);
		    String query = "UPDATE boat SET active=1,expiryDate=? WHERE idboat=?";
			
			PreparedStatement statement = connection.prepareStatement(query);
			
			statement.setString(1, dateString);
			statement.setInt(2, idboat);
			
			//System.out.println(statement);
			
			statement.executeUpdate();
			
			statement.close();
			connection.close();
			
		}catch (SQLException e) {
			System.out.println("Connection error");
			e.printStackTrace();
			
		}
	}
	
	public void addCompetitionRegistration(int idMemberReg, int idBoatReg,int idCompetitionReg) {
		try {
			Connection connection = DriverManager.getConnection(URL,USERNAME,PASSWORD);
			//System.out.println("Connected");
		    
			String sql = "INSERT INTO registration (idMemberReg, idBoatReg, idCompetitionReg ) VALUES (?,?,?)";
			
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setInt(1, idMemberReg);
			statement.setInt(2,idBoatReg);
			statement.setInt(3, idCompetitionReg);
			
			statement.executeUpdate();
			
			statement.close();
			connection.close();
			
		}catch (SQLException e) {
			System.out.println("Connection error");
			e.printStackTrace();
			
		}
	}
	
	public void addPayment(int idMemberPay, int amount, String reason, String typePayment, String codePayment ) {
		try {
			Connection connection = DriverManager.getConnection(URL,USERNAME,PASSWORD);
			//System.out.println("Connected");
		    
			String sql = "INSERT INTO payment (idMemberPay, amount, reason, typePayment, codePayment ) VALUES (?,?,?,?,?)";
			
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setInt(1, idMemberPay);
			statement.setInt(2,amount);
			statement.setString(3, reason);
			statement.setString(4, typePayment);
			statement.setString(5, codePayment);
			
			statement.executeUpdate();
			
			statement.close();
			connection.close();
			
		}catch (SQLException e) {
			System.out.println("Connection error");
			e.printStackTrace();
			
		}
	}
	
	public String getNameMemberFromId (int idMember) {
		String name = null;
			try {
			
			Connection connection = DriverManager.getConnection(URL,USERNAME,PASSWORD);
			
			String query = "SELECT name,surname FROM member WHERE idMember=?";
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setInt(1, idMember);
			ResultSet result = statement.executeQuery();
			while (result.next()) {
				name = result.getString("name") + " ";
				name += result.getString("surname");
			}
			connection.close();
			
		}catch (SQLException e) {
			System.out.println("Connection error");
			e.printStackTrace();
		}
		return name;
	}
	
	public void addCompetition (String name,String date,int idMemberOrg ) {
		try {
			Connection connection = DriverManager.getConnection(URL,USERNAME,PASSWORD);
			//System.out.println("Connected");
		    
			String sql = "INSERT INTO competition (name,date,idMemberOrg ) VALUES (?,?,?)";
			
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setString(1, name);
			statement.setString(2, date);
			statement.setInt(3, idMemberOrg );
			
			statement.executeUpdate();
			
			statement.close();
			connection.close();
			
		}catch (SQLException e) {
			System.out.println("Connection error");
			e.printStackTrace();
			
		}
	}
	
	public void updateMember(Member member) {
		try {
			
			Connection connection = DriverManager.getConnection(URL,USERNAME,PASSWORD);
			
			String query = "SELECT * FROM member WHERE idMember=?";
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setInt(1, member.getIdmember());
			ResultSet result = statement.executeQuery();
			result.next();
			member.setType(Integer.parseInt(result.getString("type")));
			connection.close();
			
		}catch (SQLException e) {
			System.out.println("Connection error");
			e.printStackTrace();
		}
	}
	
   public void start() throws IOException
    {

        System.out.println("Connection Starting on port:" + serversocket.getLocalPort() );
        client = serversocket.accept();

        System.out.println("Waiting for connection from client");
        output = new PrintWriter(new OutputStreamWriter(client.getOutputStream()));
  
        input = new BufferedReader(new InputStreamReader(client.getInputStream()));
        
        System.out.println("connesso");
        
        //output.write("FUNZIONA");
        
        output.flush();
        output.close();
        input.close();
        client.close();
    }
	
	 public static void main(String[] args)
	    {
	        Server server = new Server();
	        try 
	        {
	        	serversocket = new ServerSocket(9091);

	        } 
	        catch (IOException e) 
	        {
	  
	            e.printStackTrace();
	        }
	        while(true) 
	        {
	        	try 
	        	{
					server.start();
				} 
	        	catch (IOException e) 
	        	{

					e.printStackTrace();
				}
	        }
	    }
	
}
